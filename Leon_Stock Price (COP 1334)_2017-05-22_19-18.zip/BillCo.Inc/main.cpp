//Name:
//Stock Price
//include preprocessor directives
#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
    //declare (and initialize if initial value is known) variables
    double buyshares=2000, buyingprice=22.97, buyingcomission=0.025;
    double soldshares=2000, soldprice=27.97, sellingcomision=0.025;



    // set precision of type double variables to two digits after the decimal point
    cout << fixed << setprecision(2);

     double buypricestocks, sellpricestocks, profit, buyingtotalwcom,sellingtotalwcom;

    // calculate profit
     buypricestocks=buyshares*buyingprice; //good
     buyingtotalwcom=buypricestocks*buyingcomission; //commission 1
     sellpricestocks=soldshares*soldprice; //good
     sellingtotalwcom=sellpricestocks*sellingcomision;  //commission 2
     double totalcoms = buyingtotalwcom + sellingtotalwcom;
     double netprofit =  sellpricestocks - buypricestocks;
      profit = netprofit - totalcoms;
    // output profit
    cout << profit;

    return 0;
}
